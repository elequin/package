from acces import mul
from mod1 import sub
def add(a,b):
    c=a+b
    return c

def sqr(a):
    c=a**2
    return c

def div(a,b):
    c=a/b
    return c

print(sub(2222,4531))