def sub(a,b):
    c=a-b
    return c

def func(l):
    return(l.count(min(l)))

def sortted(l):
    return(l.sort())

def summ(a,b,c):
    s=a+b+c
    return s
