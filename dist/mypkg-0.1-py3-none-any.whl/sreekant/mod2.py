from sreekant.acces import mul
def add(a,b):
    c=a+b
    return c

def sqr(a):
    c=a**2
    return c

def div(a,b):
    c=a/b
    return c