def sub(a,b):
    c=a-b
    return c

def func(l):
    return(l.count(min(l)))

